package com.example.stomatology.app.data.repository

import com.example.stomatology.app.core.util.Resource
import com.example.stomatology.app.data.remote.ApiService
import com.example.stomatology.app.domain.model.AiAnalysisResult
import com.example.stomatology.app.domain.model.Clinic
import com.example.stomatology.app.domain.model.Finding
import com.example.stomatology.app.domain.repository.AppRepository
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import javax.inject.Inject

class AppRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val apiService: ApiService
) : AppRepository {

    override fun getClinics(): Flow<Resource<List<Clinic>>> = callbackFlow {
        trySend(Resource.Loading)

        val listener = firestore.collection("clinics")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(
                        Resource.Error(
                            message = error.message ?: "Failed to load clinics",
                            throwable = error
                        )
                    )
                    return@addSnapshotListener
                }

                val clinics = snapshot?.documents
                    ?.mapNotNull { document ->
                        document.toObject(Clinic::class.java)?.copy(id = document.id)
                    }
                    ?: emptyList()

                trySend(Resource.Success(clinics))
            }

        awaitClose { listener.remove() }
    }

    override suspend fun analyzeImage(file: File): Resource<AiAnalysisResult> {
        return try {
            val requestFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
            val body = MultipartBody.Part.createFormData("file", file.name, requestFile)

            val response = apiService.analyzeXray(body)

            val findings = response.teethData?.map { dto ->
                Finding(
                    toothClass = dto.toothName.orEmpty(),
                    conditions = dto.conditions ?: emptyList()
                )
            } ?: emptyList()

            Resource.Success(
                AiAnalysisResult(
                    teethCount = response.teethCount ?: 0,
                    findings = findings
                )
            )
        } catch (e: Exception) {
            Resource.Error(
                message = e.message ?: "Failed to analyze image",
                throwable = e
            )
        }
    }
}