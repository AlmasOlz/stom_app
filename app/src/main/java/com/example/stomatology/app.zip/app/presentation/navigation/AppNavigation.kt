package com.example.stomatology.app.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.stomatology.app.presentation.ai_analysis.AiAnalysisScreen
import com.example.stomatology.app.presentation.auth.LoginScreen
import com.example.stomatology.app.presentation.auth.RegistrationScreen
import com.example.stomatology.app.presentation.booking.BookingFormScreen
import com.example.stomatology.app.presentation.booking.BookingScreen
import com.example.stomatology.app.presentation.booking.DateTimePickerScreen
import com.example.stomatology.app.presentation.clinics.ClinicListScreen
import com.example.stomatology.app.presentation.clinics.PromoDetailScreen
import com.example.stomatology.app.presentation.doctors.DoctorListScreen
import com.example.stomatology.app.presentation.doctors.DoctorProfileScreen
import com.example.stomatology.app.presentation.education.LessonScreen
import com.example.stomatology.app.presentation.home.HomeScreen
import com.example.stomatology.app.presentation.notifications.NotificationHistoryScreen
import com.example.stomatology.app.presentation.profile.NotificationSettingsScreen
import com.example.stomatology.app.presentation.profile.ProfileEditScreen
import com.example.stomatology.app.presentation.profile.ProfileScreen
import com.example.stomatology.app.presentation.records.MyRecordsScreen
import com.example.stomatology.app.presentation.recovery.OtherServicesScreen
import com.example.stomatology.app.presentation.recovery.RecoveryScreen
import com.example.stomatology.app.presentation.reminders.RemindersScreen
import com.example.stomatology.app.presentation.theme.PrimaryBlue
import com.example.stomatology.app.presentation.tracking.TrackingScreen

sealed class BottomNavItem(
    val route: String,
    val icon: ImageVector,
    val label: String
) {
    object Notifications : BottomNavItem("notifications", Icons.Default.Notifications, "Уведомления")
    object Dashboard : BottomNavItem("dashboard", Icons.Default.Menu, "Прогресс")
    object Home : BottomNavItem("home", Icons.Default.Home, "Главная")
    object Records : BottomNavItem("records", Icons.Default.List, "Записи")
    object Profile : BottomNavItem("profile", Icons.Default.Person, "Профиль")
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    val bottomBarRoutes = listOf(
        BottomNavItem.Notifications.route,
        BottomNavItem.Dashboard.route,
        BottomNavItem.Home.route,
        BottomNavItem.Records.route,
        BottomNavItem.Profile.route
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            if (currentRoute in bottomBarRoutes) {
                BottomNavigationBar(
                    navController = navController,
                    currentRoute = currentRoute
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = BottomNavItem.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {

            // Bottom navigation screens
            composable(BottomNavItem.Notifications.route) {
                NotificationHistoryScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            composable(BottomNavItem.Dashboard.route) {
                TrackingScreen(
                    onBack = { navController.popBackStack() },
                    onNavigateToReminders = { navController.navigate("reminders") },
                    onNavigateToLesson = { topic ->
                        navController.navigate("lesson/$topic")
                    }
                )
            }

            composable(BottomNavItem.Home.route) {
                HomeScreen(
                    onNavigateToClinics = { navController.navigate("clinics") },
                    onNavigateToAi = { navController.navigate("ai_analysis") },
                    onNavigateToOtherServices = { navController.navigate("other_services") }
                )
            }

            composable(BottomNavItem.Records.route) {
                MyRecordsScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            composable(BottomNavItem.Profile.route) {
                ProfileScreen(
                    onEditProfile = { navController.navigate("profile_edit") },
                    onNotifications = { navController.navigate("notification_settings") }
                )
            }

            // Secondary screens
            composable("promo_detail") {
                PromoDetailScreen(
                    onBack = { navController.popBackStack() },
                    onBookClick = { navController.navigate("doctor_list") }
                )
            }

            composable("doctor_list") {
                DoctorListScreen(
                    onDoctorClick = { doctorName ->
                        navController.navigate("doctor_profile/$doctorName")
                    }
                )
            }

            composable("doctor_profile/{doctorName}") { backStackEntry ->
                val doctorName = backStackEntry.arguments?.getString("doctorName") ?: "Doctor"
                DoctorProfileScreen(
                    doctorName = doctorName,
                    onBookClick = { navController.navigate("date_time_picker") }
                )
            }

            composable("date_time_picker") {
                DateTimePickerScreen(
                    onConfirm = { _, _ ->
                        navController.navigate("booking_form")
                    }
                )
            }

            composable("booking_form") {
                BookingFormScreen(
                    date = "19 Март",
                    time = "14:30",
                    duration = "1 час",
                    direction = "Терапия",
                    clinicName = "OneDent",
                    doctorName = "Доктор",
                    onContinue = {
                        navController.popBackStack(BottomNavItem.Home.route, inclusive = false)
                    }
                )
            }

            composable("profile_edit") {
                ProfileEditScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            composable("notification_settings") {
                NotificationSettingsScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            composable("other_services") {
                OtherServicesScreen(
                    onBack = { navController.popBackStack() },
                    onServiceSelected = {
                        navController.popBackStack()
                    }
                )
            }

            composable("recovery") {
                RecoveryScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            composable("reminders") {
                RemindersScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            composable("lesson/{topic}") { backStackEntry ->
                val topic = backStackEntry.arguments?.getString("topic") ?: "Lesson"
                LessonScreen(
                    topic = topic,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("ai_analysis") {
                AiAnalysisScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            composable("login") {
                LoginScreen(
                    onLoginSuccess = {
                        navController.navigate(BottomNavItem.Home.route) {
                            popUpTo("login") { inclusive = true }
                        }
                    },
                    onNavigateToRegister = {
                        navController.navigate("register")
                    }
                )
            }

            composable("register") {
                RegistrationScreen(
                    onRegisterSuccess = {
                        navController.navigate(BottomNavItem.Home.route) {
                            popUpTo("login") { inclusive = true }
                        }
                    },
                    onNavigateToLogin = { navController.popBackStack() }
                )
            }

            composable("clinics") {
                ClinicListScreen(
                    onBack = { navController.popBackStack() },
                    onClinicClick = { clinicId ->
                        navController.navigate("booking/$clinicId")
                    }
                )
            }

            composable("booking/{clinicId}") { backStackEntry ->
                val clinicId = backStackEntry.arguments?.getString("clinicId") ?: ""
                BookingScreen(
                    clinicId = clinicId,
                    onBookingComplete = {
                        navController.popBackStack(BottomNavItem.Home.route, inclusive = false)
                    }
                )
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    navController: NavHostController,
    currentRoute: String?
) {
    val items = listOf(
        BottomNavItem.Notifications,
        BottomNavItem.Dashboard,
        BottomNavItem.Home,
        BottomNavItem.Records,
        BottomNavItem.Profile
    )

    NavigationBar(
        containerColor = PrimaryBlue,
        contentColor = MaterialTheme.colorScheme.onPrimary
    ) {
        items.forEach { item ->
            NavigationBarItem(
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label
                    )
                },
                selected = currentRoute == item.route,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PrimaryBlue,
                    unselectedIconColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f),
                    indicatorColor = MaterialTheme.colorScheme.onPrimary
                ),
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.startDestinationId) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                }
            )
        }
    }
}