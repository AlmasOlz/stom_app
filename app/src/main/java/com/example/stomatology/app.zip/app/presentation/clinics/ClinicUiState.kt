package com.example.stomatology.app.presentation.clinics

import com.example.stomatology.app.domain.model.Clinic

data class ClinicUiState(
    val clinics: List<Clinic> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)